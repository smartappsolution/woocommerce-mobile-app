=== WooCommerce Mobile App (Android and iOS) ===
Contributors: dharmendra
Tags: woocommerce app, mobile app, android app, ios app, shopping app, woocommerce mobile app
Requires at least: 3.1
Tested up to: 3.7.1
Stable tag: 1.1.0
License: GPL v3
License URI: http://www.gnu.org/licenses/gpl-3.0.html


WooCommerce Mobile App is a powerful, extendable eCommerce plugin that help you to create mobile app on Android and iOS platofrm. This platform has widget system, that customize app home page. It is developed by smartappsolution.net

== Description ==
WooCommerce is free extension where you can create widget for mobile app. There are some types of widget we have added in this plugin. you can enable disable on your needs. This is hybrid app

1) Category Widget : It is an category type of widget that help you to show category on home page screen of app. You can show also list or Grid View of Category Section. Also included Title for widget.

2) Product Widget : You can show category on home page screen on mobile app. where product price and rating also shown.

3) Image Widget : This is image or promotion banner image. The image have also deep linking that help you to target another page.

4) Youtube Widget : Also add youtube video on app.

5) Banner(Image Gallery) : It is showing app more beautifull.

Above are all widget that make app more beautifull and powefull.

== Installation ==
1. Upload `wooapp` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress


== Frequently asked questions ==

= How can I preview my app? =
We will provide a link to download app, where you can see preview app real time.

= Is it app free ? = 
No you can preview your app free, once you finalize our sales team contact you then you will purchase this app.

= How can I add my custom features in app ? = 
We will also do customization for app according to your site.

= How many payment gateway you support? =
We have support paypal, payUMoney, COD, addition will be chargeble.

= Is any publishing cost ? = 
We have also provide publishing service , you can purchase from us.