<?php
if(!empty($_POST)){
	$app_theme = isset($_POST['app_theme']) ? $_POST['app_theme'] : "";
	if($app_theme){
		if($app_theme == 'custom-theme'){
			$default_css_file = WPSWS_PLUGIN_DIR."assets/css/themes/theme-default-copy.css";
			$default_css_content = file_get_contents($default_css_file);
			if(isset($_POST['personalization'])){
				$personalization = $_POST['personalization'];
				foreach ($personalization as $var_key => $color_code) {
					$default_css_content = str_replace($var_key, $color_code , $default_css_content);
				}
			}
			file_put_contents(WPSWS_PLUGIN_DIR."assets/css/themes/custom-theme.css", $default_css_content);
			if ( get_option( 'wcma_app_theme_customdata' ) !== false ) {
				update_option( 'wcma_app_theme_customdata', serialize($personalization) );
			}else{
				add_option( 'wcma_app_theme_customdata', serialize($personalization), $deprecated, $autoload );
			}
		}
		file_put_contents(WPSWS_PLUGIN_DIR."assets/css/custom.css", "@import url('themes/$app_theme.css');");
		$deprecated = null; $autoload = 'no';
		if ( get_option( 'wcma_app_theme_name' ) !== false ) {
			update_option( 'wcma_app_theme_name', $app_theme );
		}else{
			add_option( 'wcma_app_theme_name', $app_theme, $deprecated, $autoload );
		}
	}
}
function wcma_add_custom_settings_admin_menu() { 
    add_submenu_page('edit.php?post_type=app_widgets', 'Advance Setting', 'Advance Setting', 'manage_options', 'admin.php?page=wcapp-adv-setting', 'wcma_add_custom_settings_admin_menu_content'); 
}
add_action('admin_menu', 'wcma_add_custom_settings_admin_menu'); 

add_action( 'admin_enqueue_scripts', 'scma_enqueue_color_picker' );
function scma_enqueue_color_picker( $hook_suffix ) {
    wp_enqueue_style( 'wp-color-picker' );
    wp_enqueue_script( 'my-script-handle', plugins_url('asset/js/personalizer.js', __FILE__ ), array( 'wp-color-picker' ), false, true );
}

function wcma_add_custom_settings_admin_menu_content()
{
?>
	<div class="wrap">
		<h1>Edit App</h1>
		<form name="edit_app" action="" method="post" id="edit_app" enctype="multipart/form-data">
			<div id="poststuff">
				<div id="post-body" class="metabox-holder columns-2">
					<div id="postbox-container-1" class="postbox-container">
						<div id="side-sortables" class="meta-box-sortables ui-sortable">
							<div id="submitdiv" class="postbox">
								<button type="button" class="handlediv button-link" aria-expanded="true"><span class="screen-reader-text">Toggle panel: Save</span><span class="toggle-indicator" aria-hidden="true"></span></button>
								<h2 class="hndle ui-sortable-handle"><span><?php echo __('Save')?></span></h2>
								<div class="inside">
									<div class="submitbox" id="submitpost">
										<div id="major-publishing-actions">
											<div id="publishing-action">
												<span class="spinner"></span>
												<input name="save" type="submit" class="button button-primary button-large" id="publish" value="Save">
											</div>
											<div class="clear"></div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div id="postbox-container-2" class="postbox-container">
						<div id="normal-sortables" class="meta-box-sortables ui-sortable">
							<div id="staff_meta" class="postbox">
								<button type="button" class="handlediv button-link" aria-expanded="true"><span class="screen-reader-text">Toggle panel: Theme Personalization</span><span class="toggle-indicator" aria-hidden="true"></span></button>
								<h2 class="hndle ui-sortable-handle"><span><?php echo __('Personalize Your Theme')?></span></h2>
								<div class="inside">
									<ul class="panel wooapp_options_panel">
										<li class="form-field">
											<label for="app_theme"><?php echo __( 'Select Theme' );?></label>
											<?php $theme_name = get_option( 'wcma_app_theme_name' )?>
											<select name="app_theme" onchange="getSelectedThemeContent(this);">
												<option>Select Theme</option>
												<option <?php if($theme_name == 'theme-green') echo "selected"?> value="theme-green">Theme Green</option>
												<option <?php if($theme_name == 'theme-sienna') echo "selected"?> value="theme-sienna">Theme Sienna</option>
												<option <?php if($theme_name == 'theme-voilet') echo "selected"?> value="theme-voilet">Theme Voilet</option>
												<option <?php if($theme_name == 'theme-seagreen') echo "selected"?> value="theme-seagreen">Theme Sea Green</option>
												<option <?php if($theme_name == 'custom-theme') echo "selected"?> value="custom-theme">Custom Theme</option>
											</select>
										</li>

										<?php
										$customdata = get_option( 'wcma_app_theme_customdata' );
										$customdata = unserialize($customdata);
										?>
										<li class="form-field custom-theme-field hidden-field" style="display:none;">
											<label for="app_theme"><?php echo __( 'Header Background Color' );?></label>
											<input type="text" value="<?php echo isset($customdata['header_bg_color']) ? $customdata['header_bg_color'] : '#009688'?>" class="color-picker" name="personalization[header_bg_color]" />
										</li>

										<li class="form-field custom-theme-field hidden-field" style="display:none;">
											<label for="app_theme"><?php echo __( 'Header Icon Color' );?></label>
											<input type="text" value="<?php echo isset($customdata['header_icon_color']) ? $customdata['header_icon_color'] : '#ffffff'?>" class="color-picker" name="personalization[header_icon_color]" />
										</li>

										<li class="form-field custom-theme-field hidden-field" style="display:none;">
											<label for="app_theme"><?php echo __( 'Header Text Color' );?></label>
											<input type="text" value="<?php echo isset($customdata['header_text_color']) ? $customdata['header_text_color'] : '#ffffff'?>" class="color-picker" name="personalization[header_text_color]" />
										</li>

										<li class="form-field custom-theme-field hidden-field" style="display:none;">
											<label for="app_theme"><?php echo __( 'Footer Background Color' );?></label>
											<input type="text" value="<?php echo isset($customdata['footer_bg_color']) ? $customdata['footer_bg_color'] : '#009688'?>" class="color-picker" name="personalization[footer_bg_color]" />
										</li>

										<li class="form-field custom-theme-field hidden-field" style="display:none;">
											<label for="app_theme"><?php echo __( 'Footer Text Color' );?></label>
											<input type="text" value="<?php echo isset($customdata['footer_text_color']) ? $customdata['footer_text_color'] : '#ffffff'?>" class="color-picker" name="personalization[footer_text_color]" />
										</li>

										<li class="form-field custom-theme-field hidden-field" style="display:none;">
											<label for="app_theme"><?php echo __( 'PopUp Button Background' );?></label>
											<input type="text" value="<?php echo isset($customdata['popup_background_color']) ? $customdata['popup_background_color'] : '#009688'?>" class="color-picker" name="personalization[popup_background_color]" />
										</li>

										<li class="form-field custom-theme-field hidden-field" style="display:none;">
											<label for="app_theme"><?php echo __( 'Widget Title Text Color' );?></label>
											<input type="text" value="<?php echo isset($customdata['widget_text_color']) ? $customdata['widget_text_color'] : '#009688'?>" class="color-picker" name="personalization[widget_text_color]" />
										</li>

										<li class="form-field custom-theme-field hidden-field" style="display:none;">
											<label for="app_theme"><?php echo __( 'Widget Product Name Color' );?></label>
											<input type="text" value="<?php echo isset($customdata['widget_product_name_color']) ? $customdata['widget_product_name_color'] : '#00000'?>" class="color-picker" name="personalization[widget_product_name_color]" />
										</li>

										<li class="form-field custom-theme-field hidden-field" style="display:none;">
											<label for="app_theme"><?php echo __( 'Rating icon color' );?></label>
											<input type="text" value="<?php echo isset($customdata['rating_icon_color']) ? $customdata['rating_icon_color'] : '#bada55'?>" class="color-picker" name="personalization[rating_icon_color]" />
										</li>

										<li class="form-field custom-theme-field hidden-field" style="display:none;">
											<label for="app_theme"><?php echo __( 'Menu Item text color' );?></label>
											<input type="text" value="<?php echo isset($customdata['menu_item_text_color']) ? $customdata['menu_item_text_color'] : '#040404'?>" class="color-picker" name="personalization[menu_item_text_color]" />
										</li>

									</ul>
									<script>
										function getSelectedThemeContent(e){
											if(e.value){
												jQuery('.hidden-field').hide();
												if(e.value == 'custom-theme'){
													jQuery('.custom-theme-field').show();
												}
											}
										}
										jQuery(document).ready(function(){
										    jQuery('.color-picker').wpColorPicker();
										    var selected = "<?php echo $theme_name ?>";

										    if(selected == 'custom-theme'){
										    	jQuery('.custom-theme-field').show();
										    }else{
										    	jQuery('.custom-theme-field').hide();
										    }
										});
									</script>
								</div>
							</div>
						</div>
					</div>
				</div>				
			</div>
		</form>
	</div>
<?php
}
?>