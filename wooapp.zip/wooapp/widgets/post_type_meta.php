<?php
// Function that adds a meta box to 'Staff Member'
function staff_meta() {
    add_meta_box( 'staff_meta', 'Widget Details', 'staff_meta_functions', 'app_widgets', 'normal', 'high' );
}

function get_widget_all_categories()
{
    $args = array(
        'number'     => 1000,
        'orderby'    => 'title',
        'order'      => 'ASC',
        'hide_empty' => false,
    );
    $product_categories = get_terms( 'product_cat', $args );
    $count = count($product_categories);
    $_product_categories = array();
    if ( $count > 0 ){
        foreach ( $product_categories as $product_category ) {
            $_product_categories[] = $product_category;       
        }
    }
    return $_product_categories;
}

function get_widget_all_products(){
    $args     = array( 'post_type' => 'product' , 'posts_per_page' => 10000);
    $products = get_posts( $args ); 
    return $products;
}

// Form in the meta box
function staff_meta_functions() {

    global $post;

    wp_nonce_field( plugin_basename( __FILE__ ), 'staff_meta_functions_nonce' ); // Create nonce to protect post

    // If meta exists, get it
    $widget_name = get_post_meta($post->ID, 'widget_name', true);
    $widget_enable = get_post_meta($post->ID, 'widget_enable', true);
    $widget_position = get_post_meta($post->ID, 'widget_position', true);
    $widget_type = get_post_meta($post->ID, 'widget_type', true);
    $widget_value = get_post_meta($post->ID, 'widget_value', true);

    $widget_value = isset($widget_value) ? unserialize($widget_value) : '';
    //echo "<pre>"; print_r($widget_value); echo "</pre>"; //exit();
    $_htmlId = 'banner';
    $_htmlName = 'banner';
    ?>
    <script src="<?php echo plugins_url().'/wooapp/assets/js/prototype.js' ?>"></script>
    <ul class="panel wooapp_options_panel">
        <li class="form-field">
            <label for="widget_name">Name</label>
            <input class="short " type="text" name="widget[widget_name]" id="widget_name" value="<?php
                if(isset($widget_name)) {
                    echo $widget_name;
                }
                ?>" />
        </li>
        <li class="form-field">
            <label for="widget_enable">Enable</label>
            <?php $widget_enable = isset($widget_enable) ? $widget_enable : '';?>
            <select name="widget[widget_enable]" id="widget_enable" class="select short">
                <option  value="1" <?php if($widget_enable == '1') echo "selected"; ?> >Yes</option>
                <option  value="0" <?php if($widget_enable == '0') echo "selected"; ?> >No</option>
            </select>
        </li>
        <li class="form-field">
            <label for="widget_position">Position</label>
            <?php $widget_position = isset($widget_position) ? $widget_position : '';?>
            <input class="short " type="text" name="widget[widget_position]" id="widget_position" value="<?php echo $widget_position; ?>" />
        </li>
        <li class="form-field">
            <label for="widget_type">Type</label>
            <?php $widget_type = isset($widget_type) ? $widget_type : '';?>
            <select name="widget[widget_type]" class="select short" id="widget_type" onchange="getSelectedTypeContent(this);" <?php if($widget_type) echo "disabled"; ?> >
                <option value="">Please Select</option>
                <option  value="banner" <?php if($widget_type == 'banner') echo "selected"; ?> >Banner</option>
                <option  value="product" <?php if($widget_type == 'product') echo "selected"; ?> >Products</option>
                <option  value="category" <?php if($widget_type == 'category') echo "selected"; ?> >Categories</option>
                <option  value="image" <?php if($widget_type == 'image') echo "selected"; ?> >Image/Promotion</option>
                <option  value="youtube" <?php if($widget_type == 'youtube') echo "selected"; ?> >Youtube Video</option>
            </select>
            <?php if($widget_type):?>
                <input type="hidden" name="widget[widget_type]" value="<?php echo $widget_type;?>"/>
            <?php endif;?>
        </li>

        <!-- Banner Widget Start Here -->
        <li class="form-field banner-field hidden-field" style="display:none;">
            <label for="widget_banner">Banners</label>
            <table class="data-table form-list" id="banner_table">
                <colgroup><col width="1">
                <col width="1">
                <col width="1">
                <col width="1">
                </colgroup><thead>
                    <tr>
                        <th>Image</th>
                        <th>Status</th>
                        <th>Position</th>
                        <th><span class="nobr">Action</span></th>
                    </tr>
                </thead>
                <tbody id="banner_container"></tbody>
                <tfoot>
                    <tr>
                        <td colspan="4" class="a-right"><button id="add_select_row_button_1" title="Add New Row" type="button" class="button button-primary button-large" onclick="bannerControl.addItem()" style=""><span><span><span>Add New Banner</span></span></span></button></td>
                    </tr>
                </tfoot>
            </table>
        </li>
        <!--  Banner Widget End Here -->

        <!-- Product Widget Start Here -->
        <?php $products = get_widget_all_products();?>
        <li class="form-field product-field hidden-field" style="display:none;">
            <label for="widget_product_ids">Products</label>
            <select name="widget[value][product][ids][]" class="select short" id="widget_product_ids" multiple>
                <?php foreach ($products as $key => $product): ?>
                    <?php $pro_id = $product->ID; 
                    $sel = '';
                    if($widget_type == 'product'){
                        $pro_ids = $widget_value['ids'];
                        if (in_array($pro_id, $pro_ids)) {
                            $sel = ' selected="selected" ';
                        }
                    }
                    ?>
                    <option value="<?php echo $pro_id;?>" <?php echo $sel;?> ><?php echo $product->post_title;?></option>
                <?php endforeach;?>
            </select>
        </li>
        <li class="form-field product-field hidden-field">
            <label for="widget_product_label">Product Widget Title</label>
            <input class="short " type="text" name="widget[value][product][label]" id="widget_product_label" value="<?php echo isset($widget_value['label']) ? $widget_value['label'] : '';?>" />
        </li>
        <li class="form-field product-field hidden-field">
            <label for="widget_product_layout">Product Layout Type</label>
            <?php $prolayout = isset($widget_value['layout']) ? $widget_value['layout'] : '';?>
            <select name="widget[value][product][layout]" id="widget_product_layout" class="select short">
                <option value="slider" <?php if($prolayout == 'slider') echo "selected"; ?>>Slider</option>
                <option value="grid" <?php if($prolayout == 'grid') echo "selected"; ?>>Grid</option>
            </select>
        </li>
        <!-- Product Widget End Here-->

        <!-- Category Widget Start Here -->
        <?php 
        $categories = get_widget_all_categories();
        ?>
        <li class="form-field category-field hidden-field" style="display:none;">
            <label for="widget_category_ids">Category</label>
            <select name="widget[value][category][ids][]" class="select short" id="widget_category_ids" multiple>     
                <?php foreach ($categories as $key => $category): ?>
                    <?php $term_id = $category->term_id; 
                    $sel = '';
                    $cat_ids = $widget_value['ids'];
                    if($widget_type == 'category'){
                        if (in_array($term_id, $cat_ids)) {
                            $sel = ' selected="selected" ';
                        }
                    }
                    ?>
                    <option value="<?php echo $term_id;?>" <?php echo $sel;?> >
                        <?php echo $category->name;?>
                    </option>
                <?php endforeach;?>
            </select>
        </li>
        <li class="form-field category-field hidden-field">
            <label for="widget_product_label">Category Widget Title</label>
            <input class="short " type="text" name="widget[value][category][label]" id="widget_product_label" value="<?php echo isset($widget_value['label']) ? $widget_value['label'] : '';?>" />
        </li>
        <li class="form-field category-field hidden-field">
            <label for="widget_category_layout">Category Layout Type</label>
            <?php $catlayout = isset($widget_value['layout']) ? $widget_value['layout'] : '';?>
            <select name="widget[value][category][layout]" id="widget_category_layout" class="select short">
                <option value="list" <?php if($catlayout == 'list') echo "selected"; ?>>List</option>
                <option value="grid" <?php if($catlayout == 'grid') echo "selected"; ?>>Grid</option>
            </select>
        </li>
        <!-- Category Widget End Here-->

        <!-- Image Widget Start Here -->
        <li class="form-field image-field hidden-field">
            <label for="widget_image_label">Image Widget Title</label>
            <input class="short " type="text" name="widget[value][image][label]" id="widget_image_label" value="<?php echo isset($widget_value['label']) ? $widget_value['label'] : '';?>" />
        </li>
        <li class="form-field image-field hidden-field" style="display:none;">
            <label for="widget_image_file">Upload Image</label>
            <?php if(isset($widget_value['file_path'])):?>
                <img src="<?php echo WPSWS_PLUGIN_URL.$widget_value['file_path']?>" width="30" height="30" style="float: left; ">
            <?php endif;?>
            <input type="file" name="layout_image_file" id="widget_image_file"/>            
            <input type="hidden" name="widget[value][image][file_path]" value="<?php echo isset($widget_value['file_path']) ? $widget_value['file_path'] : '';?>">
        </li>

        <li class="form-field image-field hidden-field" style="display:none;">
            <label for="widget_image_link">Image Navigation</label>
            <select name="widget[value][image][link_type]" id="widget_image_link" class="short select" onchange="getSelectedTypeImageLink(this);" >
                <?php $link_type = isset($widget_value['link_type']) ? $widget_value['link_type'] : '';?>
                <option>Select Link Type</option>
                <option value="product" <?php if($link_type == 'product') echo "selected"; ?> >Product Page</option>
                <option value="category" <?php if($link_type == 'category') echo "selected"; ?> >Category Page</option>
                <option value="external" <?php if($link_type == 'external') echo "selected"; ?> >External URL</option>
                <option value="phone" <?php if($link_type == 'phone') echo "selected"; ?> >Phone Call</option>
                <option value="email" <?php if($link_type == 'email') echo "selected"; ?> >Email</option>
            </select>
        </li>

        <li class="form-field product-image-link-field hidden-field image-link-field" style="display:none;">
            <label for="widget_product_ids">Select Product</label>
            <select name="widget[value][image][value][p_id]" class="select short" id="widget_product_ids" >
                <?php foreach ($products as $key => $product): ?>
                    <?php $pro_id = $product->ID; 
                    $sel = '';
                    if($link_type == 'product'){
                        $sel_pro_id = $widget_value['value']['p_id'];
                        if ($sel_pro_id == $pro_id) {
                            $sel = ' selected="selected" ';
                        }
                    }
                    ?>
                    <option value="<?php echo $pro_id;?>" <?php echo $sel;?> ><?php echo $product->post_title;?></option>
                <?php endforeach;?>
            </select>
        </li>
        <li class="form-field category-image-link-field hidden-field image-link-field" style="display:none;">
            <label for="widget_category_id">Select Category</label>
            <select name="widget[value][image][value][c_id]" class="select short" id="widget_category_id" >     
                <?php foreach ($categories as $key => $category): ?>
                    <?php $term_id = $category->term_id; 
                    $sel = '';
                    if($link_type == 'category'){
                        $sel_cat_id = $widget_value['value']['c_id'];
                        if ($term_id == $sel_cat_id) {
                            $sel = ' selected="selected" ';
                        }
                    }
                    ?>
                    <option value="<?php echo $term_id;?>" <?php echo $sel;?> >
                        <?php echo $category->name;?>
                    </option>
                <?php endforeach;?>
            </select>
        </li>

        <li class="form-field external-image-link-field hidden-field image-link-field">
            <label for="external_image_link">External URL</label>
            <?php 
            $external_url = '';
            if($link_type == 'external'){
                $external_url = $widget_value['value']['external'];
            }
            ?>
            <input class="short " type="text" name="widget[value][image][value][external]" id="external_image_link" value="<?php echo $external_url;?>" />
        </li>
        <li class="form-field phone-image-link-field hidden-field image-link-field">
            <label for="phone_image_link">Phone Number</label>
            <?php 
            $phone = '';
            if($link_type == 'phone'){
                $phone = $widget_value['value']['phone'];
            }
            ?>
            <input class="short " type="text" name="widget[value][image][value][phone]" id="phone_image_link" value="<?php echo $phone;?>" />
        </li>
        <li class="form-field email-image-link-field hidden-field image-link-field">
            <label for="email_image_link">Email Id</label>
            <?php 
            $email = '';
            if($link_type == 'email'){
                $email = $widget_value['value']['email'];
            }
            ?>
            <input class="short " type="text" name="widget[value][image][value][email]" id="email_image_link" value="<?php echo $email;?>" />
        </li>
        <!-- Image Widget End Here -->

        <!-- Youtube Video Widget Start Here -->
        <li class="form-field youtube-field hidden-field">
            <label for="widget_youtube_label">Youtube Widget Title</label>
            <input class="short " type="text" name="widget[value][youtube][label]" id="widget_youtube_label" value="<?php echo isset($widget_value['label']) ? $widget_value['label'] : '';?>" />
        </li>
        <li class="form-field youtube-field hidden-field">
            <label for="widget_youtube_url">Youtube Embeded URL</label>
            <input class="short " type="text" name="widget[value][youtube][url]" id="widget_youtube_url" value="<?php echo isset($widget_value['url']) ? $widget_value['url'] : '';?>" />
        </li>
        <li class="form-field youtube-field hidden-field">
            <label for="allow_full_screen">Allow Full Screen</label>
            <?php $allow_full_screen = isset($widget_value['allow_full_screen']) ? $widget_value['allow_full_screen'] : '0';?>
            <select name="widget[value][youtube][allow_full_screen]" id="allow_full_screen" class="select short">
                <option  value="1" <?php if($allow_full_screen == '1') echo "selected"; ?> >Yes</option>
                <option  value="0" <?php if($allow_full_screen == '0') echo "selected"; ?> >No</option>
            </select>
        </li>
        <!-- Youtube Video Widget End Here -->
    </ul>

    <script type="text/javascript">
        function getSelectedTypeContent(e) {
            if(e.value){
                jQuery('.hidden-field').hide();
                if(e.value == 'banner'){
                    jQuery('.banner-field').show();
                }else if(e.value == 'product'){
                    jQuery('.product-field').show();
                }else if(e.value == 'category'){
                    jQuery('.category-field').show();
                }else if(e.value == 'image'){
                    jQuery('.image-field').show();
                }else if(e.value == 'youtube'){
                    jQuery('.youtube-field').show();
                }
            }else{
                jQuery('.hidden-field').hide();
            }
        }

        function getSelectedTypeImageLink(e) {
            if(e.value){
                jQuery('.image-link-field').hide();
                if(e.value == 'product'){
                    jQuery('.product-image-link-field').show();
                }else if(e.value == 'category'){
                    jQuery('.category-image-link-field').show();
                }else if(e.value == 'external'){
                    jQuery('.external-image-link-field').show();
                }else if(e.value == 'phone'){
                    jQuery('.phone-image-link-field').show();
                }else if(e.value == 'email'){
                    jQuery('.email-image-link-field').show();
                }
            }else{
                jQuery('.image-link-field').hide();
            }
        }
    </script>
    <script type="text/javascript">
        var media_url = '<?php echo WPSWS_PLUGIN_URL?>';
        var bannerRowTemplate = 
            '<tr>'      
                + '<input type="hidden" name="widget[value][banner][{{index}}][banner_options]" id="banner_row_{{index}}_options" />'        
                + '<td>'
                    +'<input class="" type="file" name="widget[value][banner][{{index}}]" id="banner_row_{{index}}_name"/>'
                            +'<div class="banner-image-left">'
                                + '<img id="banner_row_{{index}}_image" src="" width="22px" height="22px" style="margin-left:5px;">'
                            +'</div>'
                            + '<input id="banner_row_{{index}}_path" type="hidden" name="widget[value][banner][{{index}}][banner_path]">'
                + '</td>'  
                + '<td>'
                     + '<input  id="banner_row_{{index}}_status" type="checkbox" value="1" name="widget[value][banner][{{index}}][banner_status]">'
                + '</td>' 
                + '<td>'
                     + '<input class="input-text" style="width:50px;" id="banner_row_{{index}}_position" type="text" name="widget[value][banner][{{index}}][banner_position]">'
                + '</td>'
                + '<td class="last">'
                    + '<input type="hidden" name="widget[value][banner][{{index}}][banner_delete]" class="delete" value="0" id="banner_row_{{index}}_delete" />'
                    + '<button title="Delete" type="button" class="button button-primary button-large" id="banner_row_{{index}}_delete_button" onclick="return bannerControl.deleteItem(event);">'
                        + '<span>Delete</span>'
                    + '</button>'
                + '</td>'
            + '</tr>';
        var bannerControl = {
            template: new Template(bannerRowTemplate, new RegExp('(^|.|\\r|\\n)({{\\s*(\\w+)\\s*}})', "")),
            itemsCount: 1,
            addItem: function(){
                var data = {
                    id: 0,          
                    position: 0,                      
                    index: this.itemsCount,
                    del: 0,
                    banner_path:'',
                };
                
                if (arguments.length >= 1) {
                    data.banner_path = arguments[0];
                    data.banner_position = arguments[1];
                    data.banner_status = arguments[2];
                    data.banner_link = arguments[3];
                    this.itemsCount = data.index;
                }
                Element.insert($('banner_container'),{
                    bottom: this.template.evaluate(data)
                });                
                $('banner_row_' + data.index + '_position').value = data.position;               
                $('banner_row_' + data.index + '_options').value = data.index;
                $('banner_row_' + data.index + '_delete').value = data.del;
                if ( data.banner_path != ''){
                    if (typeof data.banner_path !== "undefined") {
                        url = media_url+data.banner_path;
                        $('banner_row_' + data.index + '_image').show();
                        $('banner_row_' + data.index + '_image').setAttribute('src',url);
                        $('banner_row_' + data.index + '_path').value = data.banner_path;
                         //$('banner_row_link_' + data.index ).value = data.banner_link;
                    }else{
                        $('banner_row_' + data.index + '_image').setAttribute('src','');
                        $('banner_row_' + data.index + '_image').hide();
                    }   
                }
                else {
                    $('banner_row_' + data.index + '_image').setAttribute('src','');
                    $('banner_row_' + data.index + '_image').hide();
                }
                if (data.banner_status == 1){
                    $('banner_row_' + data.index + '_status').checked = true;
                }
                if(data.banner_position !=''){
                    if (typeof data.banner_position !== "undefined") {
                        $('banner_row_' + data.index + '_position').value = data.banner_position;
                    }else{
                        $('banner_row_' + data.index + '_position').value = '0';
                    }
                }
                this.itemsCount++;
            },
            disableElement: function(el){
                el.disabled = true;
                el.addClassName('disabled');
            },
            deleteItem: function(event){
                var tr = Event.findElement(event, 'tr');
                if (tr){
                    Element.select(tr, '.delete').each(function(elem){elem.value='1'});
                    Element.select(tr, ['input','select']).each(function(elem){elem.hide()});
                    Element.hide(tr);
                    Element.addClassName(tr, 'no-display template');
                }
                return false;
            }
        };
        <?php if($widget_type == 'banner'):?>
            <?php 
            $banners = $widget_value;
            //print_r($banners); exit();
            if(count($banners)): ?>
                <?php 
                $image = '';
                usort($banners, function($a, $b) {
                    return $a['banner_position'] - $b['banner_position'];
                });
                foreach ($banners as $_item):?>
                    <?php if($_item['banner_delete'] != 1):?>
                        <?php echo $_htmlName ?>Control.addItem(
                            "<?php echo $_item['banner_path']; ?>",
                            "<?php echo $_item['banner_position']; ?>",
                            "<?php echo $_item['banner_status']; ?>"
                            );
                    <?php endif;?>
                <?php endforeach;?>
            <?php endif;?>
        <?php endif;?>
    </script>
    <script type="text/javascript">
        jQuery(document).ready(function(){
            var selected_widget = "<?php echo $widget_type; ?>" ;
            if(selected_widget == 'banner'){
                jQuery('.banner-field').show();
            }else if(selected_widget == 'product'){
                jQuery('.product-field').show();
            }else if(selected_widget == 'category'){
                jQuery('.category-field').show();
            }else if(selected_widget == 'image'){
                jQuery('.image-field').show();
            }else if(selected_widget == 'youtube'){
                jQuery('.youtube-field').show();
            }
            jQuery("#post").attr("enctype", "multipart/form-data");
        });

        jQuery(document).ready(function(){
            var link_type = "<?php echo $link_type; ?>" ;
            
            if(link_type == 'product'){
                jQuery('.product-image-link-field').show();
            }else if(link_type == 'category'){
                jQuery('.category-image-link-field').show();
            }else if(link_type == 'external'){
                jQuery('.external-image-link-field').show();
            }else if(link_type == 'phone'){
                jQuery('.phone-image-link-field').show();
            }else if(link_type == 'email'){
                jQuery('.email-image-link-field').show();
            }
        });
    </script>
    <style type="text/css">
        div#delete-action {
            display: none;
        }
    </style>
<?php
}

// Save any editted meta
function staff_meta_save($post_id, $post) {
    global $post;

    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )
        return false;


    if ( !current_user_can( 'edit_post', $post->ID ) ) {
        return $post->ID;
    }

    if (!wp_verify_nonce( $_POST['staff_meta_functions_nonce'], plugin_basename( __FILE__ ) ) ) {

    } else {
        $widget_data = $_POST['widget'];
        //echo "<pre>"; print_r($widget_data); exit();
        $widget_name = isset($widget_data['widget_name']) ? $widget_data['widget_name'] : '';
        $widget_enable = isset($widget_data['widget_enable']) ? $widget_data['widget_enable'] : '0';
        $widget_position = isset($widget_data['widget_position']) ? $widget_data['widget_position'] : '0';
        $widget_type = isset($widget_data['widget_type']) ? $widget_data['widget_type'] : '';
        //echo $post->ID; exit();
        switch ($widget_type) {
            case 'product':
                $product_value = $widget_data['value']['product'];
                $widget_value =  serialize($product_value);
                break;
            case 'category':
                $category_value = $widget_data['value']['category'];
                $widget_value =  serialize($category_value);
                break;
            case 'image':
                $image_value = $widget_data['value']['image'];
                
                $media_dir = WPSWS_PLUGIN_DIR.'/media/app/images/';

                if($_FILES['layout_image_file']){
                    if($_FILES['layout_image_file']['error'] == 0 ){
                        $file_name = time().'__'.$_FILES["layout_image_file"]["name"];
                        if(move_uploaded_file($_FILES["layout_image_file"]["tmp_name"], $media_dir . $file_name)) {
                            $file_path =  "/media/app/images/".$file_name;
                            $image_value['file_path'] = $file_path;
                        }

                    }
                }

                $widget_value =  serialize($image_value);
                break;
            case 'youtube':
                $youtube_value = $widget_data['value']['youtube'];
                $widget_value =  serialize($youtube_value);
                break;
            case 'banner':
                $banner_value = $widget_data['value']['banner'];

                $media_dir = WPSWS_PLUGIN_DIR.'/media/app/banners/';
                //echo WPSWS_PLUGIN_DIR; exit();
                //echo "<pre>"; print_r($_FILES); 

                if($_FILES['widget']['name']['value']['banner']){
                    $banners = $_FILES['widget']['name']['value']['banner'];
                    $files = array();
                    foreach ($banners as $index => $_value) {
                        $banner_error = $_FILES['widget']['error']['value']['banner'][$index];
                        if($banner_error == 0){
                            $file_name = time().'__'.$_FILES['widget']['name']['value']['banner'][$index];
                            $tmp_name = $_FILES['widget']['tmp_name']['value']['banner'][$index];
                            if(move_uploaded_file($tmp_name, $media_dir . $file_name)) {
                                $file_path =  "/media/app/banners/".$file_name;
                                $banner_value[$index]['banner_path'] = $file_path;
                            }
                        }
                    }
                }
                $widget_value =  serialize($banner_value);
                break;
        }
        //echo "<pre>"; print_r($widget_data);  exit();
        update_post_meta($post->ID, 'widget_name', $widget_name);
        update_post_meta($post->ID, 'widget_enable', $widget_enable);
        update_post_meta($post->ID, 'widget_position', $widget_position);
        update_post_meta($post->ID, 'widget_type', $widget_type);
        update_post_meta($post->ID, 'widget_value', $widget_value);
    }

    return false;
}

function admin_style() {
    wp_enqueue_style('admin-styles', plugins_url().'/wooapp/assets/css/admin.css');
}

// Hooks
add_action( 'admin_menu', 'staff_meta' );
add_action( 'save_post', 'staff_meta_save', 1, 2);
add_action('admin_enqueue_scripts', 'admin_style');

?>
