<?php
if($_POST){
	//echo "<pre>"; print_r($_POST); 
	if(isset($_POST['languages'])){
		$languages = $_POST['languages'];
		$file = file_get_contents(WPSWS_PLUGIN_DIR."media/app/translation/translate.xml");
		$xml = simplexml_load_string($file, "SimpleXMLElement", LIBXML_NOCDATA);

		foreach ($languages as $lang_code => $data) {
			//print_r($data);
			foreach ($data as $lang_key => $lang_value) {
				$xml->$lang_code->$lang_key = $lang_value;
			}
		}
		$xml->asXML(WPSWS_PLUGIN_DIR."media/app/translation/translate.xml");
	}
	//exit();
}
function wcma_add_labels_admin_menu() { 
    add_submenu_page('edit.php?post_type=app_widgets', 'Labels & Messages', 'Labels & Messages', 'manage_options', 'admin.php?page=wcapp-labels', 'wcma_labels_admin_menu_content'); 
}
add_action('admin_menu', 'wcma_add_labels_admin_menu');

function wcma_labels_admin_menu_content(){
?>
	<div class="wrap">
		<h1>Edit Labels and Messages</h1>
		<form name="edit_app" action="" method="post" id="edit_app" enctype="multipart/form-data">
			<div id="poststuff">
				<div id="post-body" class="metabox-holder columns-2">
					<div id="postbox-container-1" class="postbox-container">
						<div id="side-sortables" class="meta-box-sortables ui-sortable">
							<div id="submitdiv" class="postbox">
								<button type="button" class="handlediv button-link" aria-expanded="true"><span class="screen-reader-text">Toggle panel: Save</span><span class="toggle-indicator" aria-hidden="true"></span></button>
								<h2 class="hndle ui-sortable-handle"><span><?php echo __('Save')?></span></h2>
								<div class="inside">
									<div class="submitbox" id="submitpost">
										<div id="major-publishing-actions">
											<div id="delete-action">
												<?php 
												$lc = $_GET['lang_code'];
												if($lc == ''){
													$lc = 'en_US';
												}
												$admin_url = admin_url( 'edit.php?post_type=app_widgets&page=admin.php?page=wcapp-labels');
												?>
												<select onchange="swictLanguageCode(this)">
													<option value="en_US" <?php if($lc=='en_US') echo "selected"; ?> ><?php echo __('English')?></option>
													<option value="de_DE" <?php if($lc=='de_DE') echo "selected"; ?> ><?php echo __('German')?></option>
													<option value="es_ES" <?php if($lc=='es_ES') echo "selected"; ?> ><?php echo __('Spanish')?></option>
													<option value="fr_FR" <?php if($lc=='fr_FR') echo "selected"; ?> ><?php echo __('French')?></option>
													<option value="it_IT" <?php if($lc=='it_IT') echo "selected"; ?> ><?php echo __('Italian')?></option>
													<option value="nl_NL" <?php if($lc=='nl_NL') echo "selected"; ?> ><?php echo __('Dutch')?></option>
													<option value="tr_TR" <?php if($lc=='tr_TR') echo "selected"; ?> ><?php echo __('Turkish')?></option>
													<option value="ar_SA" <?php if($lc=='ar_SA') echo "selected"; ?> ><?php echo __('Arabic')?></option>
												</select>
												<script type="text/javascript">
												    function swictLanguageCode(obj){
												        var urlString = "<?php echo $admin_url; ?>";
												        var selectedLang = obj.options[obj.selectedIndex];
												        if (selectedLang.value != "nothing"){
												                window.location = urlString +'&lang_code='+ selectedLang.value;
												        }
												    }
												</script>
											</div>
											<div id="publishing-action">
												<span class="spinner"></span>
												<input name="save" type="submit" class="button button-primary button-large" id="publish" value="Save">
											</div>
											<div class="clear"></div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div id="postbox-container-2" class="postbox-container">
						<div id="normal-sortables" class="meta-box-sortables ui-sortable">
							<div id="staff_meta" class="postbox">
								<button type="button" class="handlediv button-link" aria-expanded="true"><span class="screen-reader-text">Toggle panel: Labels</span><span class="toggle-indicator" aria-hidden="true"></span></button>
								<h2 class="hndle ui-sortable-handle"><span><?php echo __('Labels And Messages')?></span></h2>
								<div class="inside">
									<ul class="panel wooapp_options_panel">
										<?php 
										$file = file_get_contents(WPSWS_PLUGIN_DIR."media/app/translation/translate.xml");

										$xml = simplexml_load_string($file, "SimpleXMLElement", LIBXML_NOCDATA);
										$json = json_encode($xml);
										$languages = json_decode($json,TRUE);

										$_languages = array();
										//echo "<pre>";
										foreach ($languages as $lang => $value):?>
											<?php if($lang == $lc):?>
											<?php foreach ($value as $key => $langvalue): ?>
											<li class="form-field">
												<label for=""><?php echo $key;?></label>
												<input class="" type="text" name="languages[<?php echo $lc?>][<?php echo $key;?>]" id="" value="<?php echo $langvalue; ?>" placeolder="<?php echo $langvalue;?>">
											</li>
											<?php endforeach;?>
											<?php endif;?>
										<?php endforeach;?>
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>				
			</div>
		</form>
	</div>
<?php 
}

?>