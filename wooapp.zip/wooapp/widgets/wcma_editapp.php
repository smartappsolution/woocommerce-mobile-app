<?php
if($_POST){

	$app_name = $_POST['app_info']['app_name'];
	$push_info = $_POST['push_info'];

	$deprecated = null; $autoload = 'no';
	if($app_name){		
		if ( get_option( 'wcma_app_name' ) !== false ) {
			update_option( 'wcma_app_name', $app_name );
		}else{
			add_option( 'wcma_app_name', $app_name, $deprecated, $autoload );
		}
	}

	if($push_info){
		if ( get_option( 'wcma_push_info' ) !== false ) {
			update_option( 'wcma_push_info', serialize($push_info) );
		}else{
			add_option( 'wcma_push_info', serialize($push_info), $deprecated, $autoload );
		}
	}
}

function wcma_add_editapp_admin_menu() { 
    add_submenu_page('edit.php?post_type=app_widgets', 'Edit App', 'Edit App', 'manage_options', 'admin.php?page=wcapp-settings', 'wcma_editapp_admin_menu_content'); 
}
add_action('admin_menu', 'wcma_add_editapp_admin_menu'); 

function wcma_editapp_admin_menu_content()
{
?>
	<div class="wrap">
		<h1>Edit App</h1>
		<form name="edit_app" action="" method="post" id="edit_app" enctype="multipart/form-data">
			<div id="poststuff">
				<div id="post-body" class="metabox-holder columns-2">
					<div id="postbox-container-1" class="postbox-container">
						<div id="side-sortables" class="meta-box-sortables ui-sortable">
							<div id="submitdiv" class="postbox">
								<button type="button" class="handlediv button-link" aria-expanded="true"><span class="screen-reader-text">Toggle panel: Save</span><span class="toggle-indicator" aria-hidden="true"></span></button>
								<h2 class="hndle ui-sortable-handle"><span><?php echo __('Save')?></span></h2>
								<div class="inside">
									<div class="submitbox" id="submitpost">
										<div id="major-publishing-actions">
											<div id="publishing-action">
												<span class="spinner"></span>
												<input name="save" type="submit" class="button button-primary button-large" id="publish" value="Save">
											</div>
											<div class="clear"></div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div id="postbox-container-2" class="postbox-container">
						<div id="normal-sortables" class="meta-box-sortables ui-sortable">
							<div id="staff_meta" class="postbox">
								<button type="button" class="handlediv button-link" aria-expanded="true"><span class="screen-reader-text">Toggle panel: App Information</span><span class="toggle-indicator" aria-hidden="true"></span></button>
								<h2 class="hndle ui-sortable-handle"><span><?php echo __('App Information')?></span></h2>
								<div class="inside">
									<ul class="panel wooapp_options_panel">
										<li class="form-field">
											<label for="app_name"><?php echo __( 'App Name' );?></label>
											<input class="short " type="text" name="app_info[app_name]" id="app_name" value="<?php echo get_option('wcma_app_name'); ?>" placeolder="<?php echo __( 'App Name' );?>">
										</li>
										<li class="form-field">
											<label for="app_name"><?php echo __( 'App Key' );?></label>
											<input class="short " type="text" name="app_info[app_key]" id="app_key" value="<?php echo get_option('wcma_app_key'); ?>" placeolder="<?php echo __( 'App Key' );?>" readonly>
										</li>
										<li class="form-field">
											<label for="app_name"><?php echo __( 'Android App Preview URL' );?></label>
											<?php if(get_option('wcma_android_app_preview_url')):?>
												<a href="<?php echo get_option('wcma_android_app_preview_url');?>">
													<?php echo get_option('wcma_android_app_preview_url');?>
												</a>
											<?php else:?>
												<span>NA</span>
											<?php endif;?>
										</li>
										<li class="form-field">
											<label for="app_name"><?php echo __( 'Android App Status' );?></label>
											<?php if(get_option('wcma_android_app_status')):?>
												<?php echo __('Ready')?>
											<?php else:?>
												<?php echo __('In Progress')?>
											<?php endif;?>
										</li>
										<li class="form-field">
											<label for="app_name"><?php echo __( 'iOS App Preview URL' );?></label>
											<?php if(get_option('wcma_ios_app_preview_url')):?>
												<a href="<?php echo get_option('wcma_ios_app_preview_url');?>">
													<?php echo get_option('wcma_ios_app_preview_url');?>
												</a>
											<?php else:?>
												<span>NA</span>
											<?php endif;?>
										</li>
										<li class="form-field">
											<label for="app_name"><?php echo __( 'App Status' );?></label>
											<?php if(get_option('wcma_ios_app_status')):?>
												<?php echo __('Ready')?>
											<?php else:?>
												<?php echo __('In Progress')?>
											<?php endif;?>
										</li>
									</ul>
								</div>
							</div>
						</div>
						<div id="normal-sortables" class="meta-box-sortables ui-sortable">
							<div id="staff_meta" class="postbox">
								<button type="button" class="handlediv button-link" aria-expanded="true"><span class="screen-reader-text">Toggle panel: Push Notification Settings</span><span class="toggle-indicator" aria-hidden="true"></span></button>
								<h2 class="hndle ui-sortable-handle"><span><?php echo __('Push Notification Settings')?></span></h2>
								<div class="inside">
									<ul class="panel wooapp_options_panel">
										<?php 
										if(get_option('wcma_push_info')) {
											$push_info = unserialize(get_option('wcma_push_info'));
										}
										?>
										<li class="form-field">
											<label for="google_api_key"><?php echo __( 'Google Api Key' );?></label>
											<input class="short " type="text" name="push_info[google_api_key]" id="google_api_key" value="<?php echo $push_info['google_api_key']; ?>" placeolder="<?php echo __( 'Google Api Key' );?>">
										</li>
										<li class="form-field">
											<label for="google_api_key"><?php echo __( 'Sender Id' );?></label>
											<input class="short " type="text" name="push_info[sender_id]" id="sender_id" value="<?php echo $push_info['sender_id']; ?>" placeolder="<?php echo __( 'Sender ID' );?>">
										</li>
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>				
			</div>
		</form>
	</div>
<?php
}
?>