<?php
// Custom column Display
add_filter( 'manage_edit-app_widgets_columns', 'edit_app_widgets_columns' ) ;

function edit_app_widgets_columns( $columns ) {
    $columns = array(
        'widget_name' => __( 'Widget Name' ),
        'widget_type' => __(' Widget Type' ),
        'widget_position' => __('Position'),
        'widget_enable' => __('Status'),
        'edit' => __('Action')
    );
    return $columns;
}

// What to display in each list column
add_action( 'manage_app_widgets_posts_custom_column', 'manage_app_widgets_columns', 10, 2 );

function manage_app_widgets_columns( $column, $post_id ) {

    // Get meta if exists
    $widget_name = get_post_meta( $post_id, 'widget_name', true );
    $widget_type = get_post_meta( $post_id, 'widget_type', true );
    $widget_position = get_post_meta( $post_id, 'widget_position', true );
    $widget_enable = get_post_meta( $post_id, 'widget_enable', true );
    switch( $column ) {

        case 'widget_name' :
            if ( empty( $widget_name ) ) {
                echo __( '' );
            } else {
                echo $widget_name;
            }
            break;

        case 'widget_type' :
            if ( empty( $widget_type ) ) {
                echo __( 'Unknown' );
            } else {
                switch ($widget_type) {
                    case 'youtube':
                        echo __( 'Youtube Video' );
                        break;
                    case 'product':
                        echo __( 'Product Widget' );
                        break;
                    case 'category':
                        echo __( 'Category Widget' );
                        break;
                    case 'image':
                        echo __( 'Image/Promotion Widget' );
                        break;
                    case 'banner':
                        echo __( 'Banner Widget' );
                        break;
                }
            }
            break;

        case 'widget_position' :
            if ( empty( $widget_position ) ) {
                echo __( 'Unknown' );
            } else {
                echo $widget_position;
            }
            break;
        case 'widget_enable' :
            if ( empty( $widget_enable ) ) {
                echo __( 'Unknown' );
            } else {
                if($widget_enable == '1'){
                    echo "Yes";
                }else{
                    echo "No";
                }
            }
            break;
        case 'edit' :
            echo '<a href="'.get_edit_post_link( $post_id ).'">EDIT</a>';
            //echo ;
            break;
    }

}

// Which columns are filterable
add_filter( 'manage_edit-staff_member_sortable_columns', 'staff_sortable_columns' );

function staff_sortable_columns( $columns ) {
    $columns['widget_name'] = 'widget_name';
    $columns['widget_type'] = 'widget_type';
    $columns['widget_position'] = 'widget_position';
    $columns['widget_enable'] = 'widget_enable';
    return $columns;
}
?>