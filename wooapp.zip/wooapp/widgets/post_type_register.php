<?php
// Create staff member post type
function wcma_register_widgets() {
    register_post_type( 'app_widgets',
        array(
            'labels' => array(
                'name' => __( 'Woo App' ),
                'singular_name' => __( 'Woo App' ),
                'menu_name' => __( 'Woo App' ),
                'all_items' => __( 'All Widgets' ),
                'add_new' => __( 'Add New Widget' ),
                'add_new_item' => __( 'Add New Widget' ),
                'edit_item' => __( 'Edit Widget' ),
                'new_item' => __( 'New Widget' ),
                'view_item' => __( 'View Widget' ),
                'search_items' => __( 'Search Widget' ),
                'not_found' => __( 'Widget Not Found' ),
                'not_found_in_trash' => __( 'Widget Not Found In Trash' ),
                'parent_item_colon' => __( 'Parent Widget' ),
                'rewrite'            => array( 'slug' => 'wooapp-mobile-menu' ),
            ),
            'menu_icon'           => 'dashicons-cart',
            'public' => true,
            'has_archive' => true,
            'supports' => array(''),
        )
    );
}



add_action( 'init', 'wcma_register_widgets' );

?>