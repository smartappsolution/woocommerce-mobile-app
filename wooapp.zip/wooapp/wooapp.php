<?php
/*
Plugin Name: Woo Mobile App
Plugin URI: http://www.smartappsolution.net/
Description: Get Woocommerce app in platform android & iOS with design interface. You can design app according to widget. Full customized your app according to requirement.
Version: 1.1.0
Author: smartappsolution
Author URI: 
License: GPL v3

*/

if ( ! defined( 'WPSWS_PLUGIN_DIR' ) ) {
	define( 'WPSWS_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
}

if ( ! defined( 'WPSWS_PLUGIN_URL' ) ) {
	define( 'WPSWS_PLUGIN_URL', plugins_url().'/wooapp' );
}

if ( ! defined( 'WPSWS_PLUGIN_FILE' ) ) {
	define( 'WPSWS_PLUGIN_FILE', __FILE__ );
}

if ( ! defined( 'API_SITE_URL' ) ) {
	define( 'API_SITE_URL', 'http://smartappsolution.net/' );
}

include_once('widgets/widgets.php');

class WP_Simple_Web_Service {

	const WEBSERVICE_REWRITE = 'webservice/([a-zA-Z0-9_-]+)$';
	const OPTION_KEY         = 'wpw_options';

	private static $instance = null;

	/**
	 * Get singleton instance of class
	 *
	 * @return null|WP_Simple_Web_Service
	 */
	public static function get() {

		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;

	}

	/**
	 * Function that runs on install
	 */
	public static function install() {
		// Clear the permalinks
		flush_rewrite_rules();
		wcma_register_widgets();

		$api_url = API_SITE_URL;
		$site_url = get_site_url()."/";
		$version = "1.0.0";
		$app_key = substr(str_shuffle(str_repeat("0123456789abcdefghijklmnopqrstuvwxyz", 5)), 0, 5);
		if(get_option('wcma_app_key')){
			$app_key = get_option('wcma_app_key');
		}
		$admin_email = get_option('admin_email');
		$site_name = get_option('blogname');
		$fields = array( 
			'site_url'=> $site_url, 
			'version'=> $version,
			'app_key' => $app_key,
			'email' => $admin_email,
			'platform' => 'wooapp',
			'app_name' => $site_name,
			);

		add_option('wcma_app_key', $app_key, '', 'no');
		add_option('wcma_app_name', $site_name, '', 'no');
		$postvars = '';
		foreach($fields as $key=>$value) {
			$postvars .= $key . "=" . $value . "&";
		}

		$url = $api_url."customer/account/installwcscript/";

		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL,$url);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $postvars);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		$server_output = curl_exec ($ch);
		//echo $server_output; exit();
		if(curl_error($ch))
		{
		   die(curl_error($ch));
		}
		curl_close ($ch);
	}

	/**
	 * Constructor
	 */
	private function __construct() {

		// Load files
		$GLOBALS['api_url'] = 'http://smartappsolution.net/index.php/';
		$GLOBALS['version'] = '1.0.0';
		$this->includes();

		// Init
		$this->init();

	}

	/**
	 * Load required files
	 */
	private function includes() {

		require_once( WPSWS_PLUGIN_DIR . 'classes/class-wpsws-rewrite-rules.php' );
		require_once( WPSWS_PLUGIN_DIR . 'classes/class-wpsws-webservice-get-posts.php' );
		require_once( WPSWS_PLUGIN_DIR . 'classes/class-wpsws-webservice-wooapp.php' );
		require_once( WPSWS_PLUGIN_DIR . 'classes/class-wpsws-webservice-product.php' );
		require_once( WPSWS_PLUGIN_DIR . 'classes/class-wpsws-webservice-cart.php' );
		require_once( WPSWS_PLUGIN_DIR . 'classes/class-wpsws-webservice-user.php' );
		require_once( WPSWS_PLUGIN_DIR . 'classes/class-wpsws-webservice-pushnotify.php' );
		if ( is_admin() ) {
			// Backend

			require_once( WPSWS_PLUGIN_DIR . 'classes/class-wpsws-settings.php' );

		}
		else {
			// Frondend

			require_once( WPSWS_PLUGIN_DIR . 'classes/class-wpsws-catch-request.php' );
			require_once( WPSWS_PLUGIN_DIR . 'classes/class-wpsws-output.php' );
		}

	}

	/**
	 * Initialize class
	 */
	private function init() {

		// Setup Rewrite Rules
		WPSWS_Rewrite_Rules::get();

		// Default webservice
		WPSWS_Webservice_get_posts::get();
		WPSWS_Webservice_wooapp::get();
		WPSWS_Webservice_cart::get();
		WPSWS_Webservice_product::get();
		WPSWS_Webservice_user::get();
		WPSWS_Webservice_pushnotify::get();
		
		if ( is_admin() ) {
			// Backend

			// Setup settings
			WPSWS_Settings::get();

		}
		else {
			// Frondend

			// Catch request
			WPSWS_Catch_Request::get();
		}

	}

	/**
	 * The correct way to throw an error in a webservice
	 *
	 * @param $error_string
	 */
	public function throw_error( $error_string ) {
		wp_die( '<b>Webservice error:</b> ' . $error_string );
	}

	/**
	 * Function to get the plugin options
	 *
	 * @return array
	 */
	public function get_options() {
		return get_option( self::OPTION_KEY, array() );
	}

	/**
	 * Function to save the plugin options
	 *
	 * @param $options
	 */
	public function save_options( $options ) {
		update_option( self::OPTION_KEY, $options );
	}

}

/**
 * Function that returns singleton instance of WP_Simple_Web_Service class
 *
 * @return null|WP_Simple_Web_Service
 */
function WP_Simple_Web_Service() {
	return WP_Simple_Web_Service::get();
}

// Load plugin
add_action( 'plugins_loaded', create_function( '', 'WP_Simple_Web_Service::get();' ) );

// Install hook
register_activation_hook( WPSWS_PLUGIN_FILE, array( 'WP_Simple_Web_Service', 'install' ) );